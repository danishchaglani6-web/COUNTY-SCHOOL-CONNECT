import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.countyschool.schoolconnect',
  appName: 'School Connect',
  webDir: 'www'
};

export default config;
