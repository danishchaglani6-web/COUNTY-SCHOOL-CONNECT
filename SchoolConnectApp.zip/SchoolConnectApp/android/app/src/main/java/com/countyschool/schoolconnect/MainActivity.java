package com.countyschool.schoolconnect;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
