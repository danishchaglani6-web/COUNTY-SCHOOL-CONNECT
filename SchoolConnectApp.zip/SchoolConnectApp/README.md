# School Connect — Mobile App (Capacitor)

This wraps your School Connect website in native Android and iOS app shells using
[Capacitor](https://capacitorjs.com). The whole site (all pages, login, dashboards)
lives in `www/index.html` and runs inside a native WebView — so it behaves exactly
like the site you already have, but installs and launches like a real app, with its
own icon and splash screen.

App name: **School Connect**
App ID: **com.countyschool.schoolconnect**

## 1. One-time setup

You need [Node.js](https://nodejs.org) installed. Then, in this folder:

```bash
npm install
```

This downloads Capacitor's tooling (not included in this zip to keep it small).

## 2. Build the Android app

Requirements: [Android Studio](https://developer.android.com/studio) (includes the
Android SDK).

```bash
npx cap open android
```

This opens the `android/` project in Android Studio. From there:
- Click **Run ▶** to install it on a connected phone or emulator, **or**
- Go to **Build → Generate Signed Bundle / APK** to produce a real installable
  `.apk` (or `.aab` for the Play Store).

## 3. Build the iOS app

Requirements: a **Mac** with [Xcode](https://apps.apple.com/app/xcode/id497799835)
installed (Apple only allows iOS builds on macOS).

```bash
npx cap open ios
```

This opens `ios/App/App.xcworkspace` in Xcode. From there:
- Select a simulator or your connected iPhone and click **Run ▶**, **or**
- Use **Product → Archive** to prepare a build for TestFlight / the App Store
  (requires a paid Apple Developer account to distribute).

## 4. Updating the app after changing the website

If you edit the website later, just replace `www/index.html` with the new version,
then run:

```bash
npx cap sync
```

This copies the updated site into both the `android/` and `ios/` native projects.
Re-run step 2 or 3 to rebuild.

## 5. Changing the app icon / splash screen

Replace `resources/icon.png` (1024×1024) and/or `resources/splash.png`
(2732×2732), then regenerate everything with:

```bash
npx @capacitor/assets generate
npx cap sync
```

## 6. Changing the app name or ID

Edit `capacitor.config.ts` (`appId` / `appName`), then run `npx cap sync`.
For Android, also update `app_name` in
`android/app/src/main/res/values/strings.xml`.
For iOS, update the **Display Name** in Xcode's target settings.

## Notes

- This is a **static demo app** — the login system uses a fixed list of demo
  accounts and browser local storage, same as the website. There's no real
  backend, matching the original project.
- The login/complaint/suggestion flows hand off to WhatsApp (`0334-6321813`)
  using the phone's WhatsApp app.
- Publishing to the Play Store / App Store requires a developer account
  ($25 one-time for Google Play, $99/year for Apple) and following each
  store's submission process — this project just gets you a working,
  installable app.
